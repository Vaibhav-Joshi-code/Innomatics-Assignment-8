import math
from math import *

p = (1.09)/(1.09+1)
print(p)
def comb(n,x):
    return (factorial(n)/(factorial(x)*factorial(n-x)))

def binomial(x,n,p):
    return comb(n,x)*(p**x)*((1-p)**(n-x))

p3 = binomial(3,6,p)
p4 = binomial(4,6,p)
p5 = binomial(5,6,p)
p6 = binomial(6,6,p)

ans = round((p3+p4+p5+p6),3)
print(ans)
