import math
from math import *

def comb(n,x):
    return (factorial(n)/(factorial(x)*factorial(n-x)))

def binomial(x,n,p):
    return comb(n,x)*(p**x)*((1-p)**(n-x))

# No more than 2 rejects
p2 = binomial(2,10,0.12)
print("Probability of getting no more than 2 rejects is: ",round(p2,3))

# Atleast 2 rejects
p0 = binomial(0,10,0.12)
p1 = binomial(1,10,0.12)
ans = 1 - (p0+p1)
print("Probability of getting atleast 2 rejects is: ",round(ans,3))
