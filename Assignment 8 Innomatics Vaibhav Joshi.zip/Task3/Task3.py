import scipy.stats as st
mn,sd = 20,2
a1 = st.norm.cdf(19.5,mn,sd)
a2 = st.norm.cdf(22,mn,sd) - st.norm.cdf(20,mn,sd)
print(round(a1,3))
print(round(a2,3))
