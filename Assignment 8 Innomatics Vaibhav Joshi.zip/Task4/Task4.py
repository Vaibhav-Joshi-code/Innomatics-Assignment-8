import scipy.stats as st
a1 = 1 - st.norm.cdf(80,70,10)
a2 = 1 - st.norm.cdf(60,70,10)
a3 = st.norm.cdf(60,70,10)
print(round(a1,3))
print(round(a2,3))
print(round(a3,3))
