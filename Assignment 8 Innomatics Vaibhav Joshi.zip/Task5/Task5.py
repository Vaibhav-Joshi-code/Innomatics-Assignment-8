import scipy.stats as st
x = int(input())
n = int(input())
mu = int(input())
sd = int(input())
nmu = n*mu
nsd2 = n*sd*sd
a = st.norm.cdf(x,nmu,nsd2)
print(round(a,3))
