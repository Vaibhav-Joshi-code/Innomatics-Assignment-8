z = 1.96 # Given
sigma = 80 # Given
n = 100 # Given
mu = 500 # Given
'''
95% confidence interval:
mu - margin of error
where margin of error = (z*sigma)/(sqrt(n))
'''
margin_of_error = (z*sigma)/(n**0.5)
A = mu - margin_of_error
B = mu + margin_of_error
print("Lower limit A is: ",A)
print("Upper limit B is: ",B)
