import numpy as np
import pandas as pd
a = np.array([-2,1.5,3.7])
b = np.array([1.2,-3.5,2.8])
d = pd.DataFrame(a,b)
print(d)
print(d.corr())
